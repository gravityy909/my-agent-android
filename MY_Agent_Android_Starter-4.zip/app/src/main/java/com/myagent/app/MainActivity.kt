package com.myagent.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101A19)
private val Panel = Color(0xFF1D2B27)
private val Lime = Color(0xFFB9F36A)
private val Muted = Color(0xFFB7C8C1)
private val White = Color(0xFFF6FAF7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyAgentApp() }
    }
}

@Composable
fun MyAgentApp() {
    var page by remember { mutableStateOf("home") }
    var mode by remember { mutableStateOf("تلقائي") }
    var drawer by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var provider by remember { mutableStateOf("OpenAI-compatible API") }
    var endpoint by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Lime, onPrimary = Ink, background = Ink, surface = Panel,
            onBackground = White, onSurface = White, secondary = Muted
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { drawer = !drawer }) {
                        Icon(Icons.Default.Menu, "القائمة", tint = White)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("MY Agent", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = White)
                        Text("مساعدك الذكي", fontSize = 12.sp, color = Muted)
                    }
                    IconButton(onClick = { page = "settings"; drawer = false }) {
                        Icon(Icons.Default.Settings, "الإعدادات", tint = White)
                    }
                }
                if (drawer) {
                    Column(Modifier.fillMaxWidth().background(Panel).padding(12.dp)) {
                        NavRow("محادثة جديدة", Icons.Default.AddComment) { messages.clear(); page = "home"; drawer = false }
                        NavRow("النماذج والاتصال", Icons.Default.Tune) { page = "models"; drawer = false }
                        NavRow("مزودات الذكاء الاصطناعي", Icons.Default.Cloud) { page = "providers"; drawer = false }
                        NavRow("الملفات", Icons.Default.FolderOpen) { page = "files"; drawer = false }
                        NavRow("الوكلاء", Icons.Default.SmartToy) { page = "agents"; drawer = false }
                        NavRow("الإعدادات", Icons.Default.Settings) { page = "settings"; drawer = false }
                    }
                }
                when (page) {
                    "settings" -> SettingsPage(mode, { mode = it })
                    "providers" -> ProvidersPage(provider, { provider = it }, endpoint, { endpoint = it }, apiKey, { apiKey = it })
                    "models" -> ModelsPage(mode, { mode = it })
                    "files" -> InfoPage("الملفات", "ستُضاف هنا إمكانية اختيار الملفات وتحليلها بعد تنفيذ صلاحيات الوصول ومعالجة الملفات.")
                    "agents" -> InfoPage("وكلائي", "سيتيح هذا القسم إنشاء وكلاء متخصصين وتعريف تعليمات مستقلة لكل وكيل.")
                    else -> ChatPage(
                        messages = messages, input = input, onInput = { input = it },
                        onSend = {
                            val text = input.trim()
                            if (text.isNotEmpty()) {
                                messages.add(true to text)
                                messages.add(false to "هذه نسخة الواجهة الأولية. لم يتم ربط محرك الذكاء الاصطناعي بعد.")
                                input = ""
                            }
                        },
                        mode = mode, onMode = { mode = it }
                    )
                }
            }
        }
    }
}

@Composable
private fun NavRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 11.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Lime)
        Spacer(Modifier.width(12.dp))
        Text(label, color = White, fontSize = 15.sp)
    }
}

@Composable
private fun ChatPage(
    messages: List<Pair<Boolean, String>>,
    input: String,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    mode: String,
    onMode: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), horizontalArrangement = Arrangement.Center) {
            listOf("محلي", "تلقائي", "سحابي").forEach { option ->
                val selected = mode == option
                Surface(
                    color = if (selected) Lime else Panel,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.padding(horizontal = 3.dp).clickable { onMode(option) }
                ) {
                    Text(option, color = if (selected) Ink else White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), fontSize = 13.sp)
                }
            }
        }
        if (messages.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(Modifier.size(68.dp).background(Lime, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Ink, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(18.dp))
                Text("مرحبًا بك في MY Agent", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = White, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("ماذا تريد أن تنجز اليوم؟", fontSize = 15.sp, color = Muted)
                Spacer(Modifier.height(24.dp))
                FeatureCard(Icons.Default.Code, "الكتابة والبرمجة", "أفكار، نصوص، ومساعدة تقنية")
                FeatureCard(Icons.Default.Description, "الملفات والمستندات", "تلخيص وتحليل — قيد التطوير")
                FeatureCard(Icons.Default.Image, "استوديو الصور", "أدوات إبداعية — قيد التطوير")
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(messages) { item ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (item.first) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (item.first) Color(0xFF304238) else Panel,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(item.second, color = White, modifier = Modifier.padding(13.dp), fontSize = 15.sp)
                        }
                    }
                }
            }
        }
        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp, top = 8.dp)) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AttachFile, null, tint = Muted)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (input.isEmpty()) Text("اكتب رسالتك إلى MY Agent...", color = Muted, fontSize = 14.sp)
                    BasicTextField(value = input, onValueChange = onInput, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp), modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = onSend, modifier = Modifier.size(42.dp).background(Lime, CircleShape)) {
                    Icon(Icons.Default.ArrowUpward, "إرسال", tint = Ink)
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Lime, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ModelsPage(mode: String, onMode: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("النماذج والاتصال", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("اختر طريقة التشغيل الافتراضية. التنفيذ الفعلي للمحركات سيُضاف في مرحلة الربط.", color = Muted)
        listOf("محلي", "تلقائي", "سحابي").forEach { option ->
            Surface(color = if (mode == option) Color(0xFF304238) else Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable { onMode(option) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = mode == option, onClick = { onMode(option) })
                    Spacer(Modifier.width(8.dp))
                    Text(option, color = White)
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(mode: String, onMode: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("الإعدادات", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("اللغة: العربية", color = White)
        Text("المظهر: داكن (التحكم بالمظهر سيُضاف لاحقًا)", color = Muted)
        Text("وضع الذكاء الافتراضي", color = White)
        listOf("محلي", "تلقائي", "سحابي").forEach { option ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = mode == option, onClick = { onMode(option) })
                Text(option, color = White)
            }
        }
        Text("تنبيه: لا تدخل مفاتيح API الحقيقية قبل إضافة تخزين آمن وربط موثوق.", color = Lime, fontSize = 13.sp)
    }
}

@Composable
private fun ProvidersPage(
    provider: String, onProvider: (String) -> Unit,
    endpoint: String, onEndpoint: (String) -> Unit,
    apiKey: String, onApiKey: (String) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("مزودات الذكاء الاصطناعي", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("واجهة إعداد أولية فقط؛ لم يتم إرسال أي طلب إلى الإنترنت.", color = Muted)
        Text("نوع المزود", color = White)
        listOf("OpenAI-compatible API", "مزود آخر متوافق").forEach { option ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = provider == option, onClick = { onProvider(option) })
                Text(option, color = White)
            }
        }
        OutlinedTextField(value = endpoint, onValueChange = onEndpoint, label = { Text("رابط API") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = apiKey, onValueChange = onApiKey, label = { Text("مفتاح API (تجريبي فقط)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Text("لا تستخدم مفتاحًا حقيقيًا في هذه النسخة؛ الحفظ مؤقت وغير آمن.", color = Lime, fontSize = 13.sp)
    }
}

@Composable
private fun InfoPage(title: String, description: String) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(description, color = Muted, fontSize = 15.sp)
    }
}
